package com.sweetcherry.entity;

public enum Role {
	ADMIN,CUSTOMER

}
