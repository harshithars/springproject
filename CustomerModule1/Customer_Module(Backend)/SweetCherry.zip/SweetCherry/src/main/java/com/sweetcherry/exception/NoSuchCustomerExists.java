package com.sweetcherry.exception;

public class NoSuchCustomerExists extends Exception{
	public NoSuchCustomerExists(String msg) {
		super(msg);
	}
	

}
