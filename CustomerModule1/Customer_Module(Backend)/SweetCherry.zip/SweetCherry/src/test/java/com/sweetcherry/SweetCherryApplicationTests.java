package com.sweetcherry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SweetCherryApplicationTests {

	@Test
	void contextLoads() {
	}

}
