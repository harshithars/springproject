import { Link } from "react-router-dom";
function Home() {
    return (
        <>
        
            <h1 className="text-center"><u>SweetCherry Application</u></h1>

            <h2 className="text-center">Welcome to Sweet Cherry App !</h2>


        </>
    );
}
export default Home;