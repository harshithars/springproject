function Contact(){
    return (
        <>
        <h1>Contact Page</h1>
        <strong>Team Members:</strong> 
        <ol>
            <li> Nisha Bharti</li>
            <li> Sojwal Sanone</li>
            <li>Urja Thakur</li>
            <li>Monisha Priyadarshini</li>
            <li> Annam Sireeja Reddy</li>
            <li> Sireesha </li>
        </ol>

        </>
    );
}
export default Contact;